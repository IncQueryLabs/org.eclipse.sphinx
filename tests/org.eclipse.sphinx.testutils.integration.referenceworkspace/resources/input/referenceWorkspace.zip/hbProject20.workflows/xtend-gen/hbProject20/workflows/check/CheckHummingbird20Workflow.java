/**
 * <copyright>
 * 
 * Copyright (c) 2014 itemis and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     itemis - Initial API and implementation
 * 
 * </copyright>
 */
package hbProject20.workflows.check;

import hbProject20.workflows.check.CheckHummingbird20WorkflowComponent;
import java.util.List;
import org.eclipse.emf.mwe2.runtime.workflow.IWorkflowComponent;
import org.eclipse.sphinx.emf.mwe.dynamic.WorkspaceWorkflow;

@SuppressWarnings("all")
public class CheckHummingbird20Workflow extends WorkspaceWorkflow {
  public CheckHummingbird20Workflow() {
    List<IWorkflowComponent> _children = this.getChildren();
    CheckHummingbird20WorkflowComponent _checkHummingbird20WorkflowComponent = new CheckHummingbird20WorkflowComponent();
    _children.add(_checkHummingbird20WorkflowComponent);
  }
}
